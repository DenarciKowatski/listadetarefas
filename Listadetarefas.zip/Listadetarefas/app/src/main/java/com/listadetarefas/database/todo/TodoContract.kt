package com.erik.listadetarefas.database.todo

import android.provider.BaseColumns
import com.erik.listadetarefas.database.user.UserContract

object TodoContract {
    object TodoEntry : BaseColumns {
        const val TABLE_NAME = "todo"
        const val COLUMN_NAME_TITLE = "title"
        const val COLUMN_NAME_DONE = "done"
        const val COLUMN_NAME_DATA = "data"
        const val COLUMN_NAME_PRIORITY = "priority"
        const val COLUMN_NAME_USER_ID = "user_id"
    }

    const val SQL_CREATE_ENTRIES =
            "CREATE TABLE ${TodoContract.TodoEntry.TABLE_NAME} (" +
                    "${BaseColumns._ID} INTEGER PRIMARY KEY," +
                    "${TodoContract.TodoEntry.COLUMN_NAME_TITLE} TEXT," +
                    "${TodoContract.TodoEntry.COLUMN_NAME_DONE} INTEGER," +
                    "${TodoContract.TodoEntry.COLUMN_NAME_DATA} TEXT," +
                    "${TodoContract.TodoEntry.COLUMN_NAME_PRIORITY} INTEGER," +
                    "${TodoContract.TodoEntry.COLUMN_NAME_USER_ID} INTEGER," +
                    "FOREIGN KEY(${TodoContract.TodoEntry.COLUMN_NAME_USER_ID}) REFERENCES" +
                    " ${UserContract.UserEntry.TABLE_NAME}(${BaseColumns._ID}))"

    const val SQL_DELETE_ENTRIES = "DROP TABLE IF EXISTS ${TodoContract.TodoEntry.TABLE_NAME}"
}